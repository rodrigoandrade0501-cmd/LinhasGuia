package br.com.linhasguia

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.max

class GuideOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var linesView: LinesView? = null
    private var handleView: TextView? = null
    private var linesParams: WindowManager.LayoutParams? = null
    private var handleParams: WindowManager.LayoutParams? = null
    private var centerX = 0.62f
    private var centerY = 0.68f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (linesView != null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        linesView = LinesView().also { view ->
            linesParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            wm.addView(view, linesParams)
        }

        handleView = TextView(this).apply {
            text = "✥"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(0x99000000.toInt())
            contentDescription = "Arraste para mover as linhas"
            setOnTouchListener(HandleTouchListener())
        }
        handleParams = WindowManager.LayoutParams(
            dp(52), dp(52),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(220)
            y = dp(520)
        }
        wm.addView(handleView, handleParams)
        updateLines()
        return START_NOT_STICKY
    }

    private inner class HandleTouchListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var downRawX = 0f
        private var downRawY = 0f

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val p = handleParams ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = p.x
                    startY = p.y
                    downRawX = event.rawX
                    downRawY = event.rawY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = startX + (event.rawX - downRawX).toInt()
                    p.y = startY + (event.rawY - downRawY).toInt()
                    wm.updateViewLayout(handleView, p)
                    centerX = (p.x + dp(26)).toFloat() / max(1, resources.displayMetrics.widthPixels)
                    centerY = (p.y + dp(26)).toFloat() / max(1, resources.displayMetrics.heightPixels)
                    updateLines()
                    return true
                }
            }
            return event.action == MotionEvent.ACTION_UP
        }
    }

    private fun updateLines() {
        val v = linesView ?: return
        v.cx = centerX * resources.displayMetrics.widthPixels
        v.cy = centerY * resources.displayMetrics.heightPixels
        v.invalidate()
    }

    private inner class LinesView : View(this@GuideOverlayService) {
        var cx = 0f
        var cy = 0f
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xCCFFFFFF.toInt()
            strokeWidth = dp(2).toFloat()
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val radius = dp(150).toFloat()
            // Four straight guides: horizontal, vertical and two diagonals.
            canvas.drawLine(cx - radius, cy, cx + radius, cy, paint)
            canvas.drawLine(cx, cy - radius, cx, cy + radius, paint)
            canvas.drawLine(cx - radius * 0.72f, cy - radius * 0.72f, cx + radius * 0.72f, cy + radius * 0.72f, paint)
            canvas.drawLine(cx - radius * 0.72f, cy + radius * 0.72f, cx + radius * 0.72f, cy - radius * 0.72f, paint)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        try { linesView?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { handleView?.let { wm.removeView(it) } } catch (_: Exception) {}
        linesView = null
        handleView = null
        super.onDestroy()
    }
}
