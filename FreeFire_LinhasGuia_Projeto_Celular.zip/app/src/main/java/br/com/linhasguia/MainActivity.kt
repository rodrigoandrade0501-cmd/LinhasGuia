package br.com.linhasguia

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private val requestOverlay = 1204

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(18, 20, 28))
        }
        val title = TextView(this).apply {
            text = "LINHAS GUIA"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "Quatro linhas transparentes para referência visual. Não há mira automática, detecção de inimigos nem interação com o jogo."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 24)
        }
        val start = Button(this).apply {
            text = "Mostrar linhas"
            setOnClickListener { enableOverlay() }
        }
        val stop = Button(this).apply {
            text = "Esconder linhas"
            setOnClickListener { stopService(Intent(this@MainActivity, GuideOverlayService::class.java)) }
        }
        layout.addView(title)
        layout.addView(desc)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivityForResult(intent, requestOverlay)
        } else {
            startService(Intent(this, GuideOverlayService::class.java))
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestOverlay && Settings.canDrawOverlays(this)) {
            startService(Intent(this, GuideOverlayService::class.java))
        }
    }
}
