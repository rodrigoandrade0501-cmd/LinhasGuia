# Linhas Guia (Android)

Projeto inicial de app Android com sobreposição transparente de quatro linhas:
- horizontal
- vertical
- duas diagonais

Um pequeno controle `✥` pode ser arrastado para mover o ponto de cruzamento. As linhas não detectam alvos, não movem a mira do jogo e não simulam toques.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `FreeFire_LinhasGuia` no Android Studio.
3. Aceite a instalação dos componentes do Android SDK sugeridos.
4. Aguarde a sincronização do Gradle.
5. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de depuração normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.

## Como usar
1. Instale o APK no seu Android.
2. Abra **Linhas Guia** e toque em **Mostrar linhas**.
3. Autorize “Exibir sobre outros apps”.
4. Arraste o pequeno controle para colocar o cruzamento das linhas perto da área desejada.
5. Volte ao jogo. Para retirar a sobreposição, abra o app e toque em **Esconder linhas**.

## Limitações
- Este ambiente não tem Android SDK nem Gradle instalados, então o APK não foi compilado aqui; este pacote contém o projeto-fonte para gerar o APK no Android Studio.
- Android e o próprio jogo podem restringir sobreposições. Use apenas se permitido pelas regras do jogo e pelo dispositivo.
- O controle arrastável é um elemento tocável e pode interceptar toques somente na sua pequena área.

## Gerar APK usando somente o celular (GitHub Actions)
1. No navegador do celular, entre em https://github.com e crie uma conta ou entre na sua conta.
2. Crie um repositório novo chamado `LinhasGuia` e marque-o como **Public** para o caminho mais simples.
3. Extraia o ZIP usando o gerenciador de arquivos do celular.
4. No site do repositório, use **Add file > Upload files** e envie todos os arquivos e pastas do projeto, incluindo a pasta oculta `.github/workflows/build-apk.yml`. Se o navegador não permitir enviar pastas/arquivos ocultos, será necessário criar o workflow pelo site em **Add file > Create new file** com o caminho `.github/workflows/build-apk.yml` e colar o conteúdo do arquivo.
5. Faça commit dos arquivos para a branch `main`.
6. Abra a aba **Actions**, selecione **Build Android APK** e, se aparecer, toque em **Run workflow**.
7. Aguarde o processo terminar com marca verde. Abra a execução e, no final, baixe o artefato **LinhasGuia-debug-apk**. Ele é um ZIP contendo `app-debug.apk`; extraia e instale o APK.
8. Se o Android bloquear a instalação, permita a instalação de apps dessa fonte nas configurações do navegador/gerenciador de arquivos, somente se confiar no APK que você acabou de compilar.

O build acontece nos servidores do GitHub, não no celular. A disponibilidade e os nomes dos botões do site podem variar.
